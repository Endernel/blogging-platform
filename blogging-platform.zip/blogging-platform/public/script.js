const blogForm = document.getElementById('blog-form');
const blogsDiv = document.getElementById('blogs');

blogForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const title = document.getElementById('title').value;
    const body = document.getElementById('body').value;
    const author = document.getElementById('author').value;

    const response = await fetch('/blogs', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ title, body, author }),
    });

    if (response.ok) {
        loadBlogs();
    } else {
        console.error('Failed to create blog post');
    }

    blogForm.reset();
});

async function loadBlogs() {
    const response = await fetch('/blogs');
    const blogs = await response.json();
    blogsDiv.innerHTML = '';

    blogs.forEach(blog => {
        const blogPost = document.createElement('div');
        blogPost.classList.add('blog-post');
        blogPost.innerHTML = `
            <h2>${blog.title}</h2>
            <p>${blog.body}</p>
            <p><strong>Author:</strong> ${blog.author}</p>
            <p><small>Published: ${new Date(blog.createdAt).toLocaleString()}</small></p>
            <button onclick="deleteBlog('${blog._id}')">Delete</button>
            <button onclick="editBlog('${blog._id}', '${blog.title}', '${blog.body}', '${blog.author}')">Edit</button>
        `;
        blogsDiv.appendChild(blogPost);
    });
}

async function deleteBlog(id) {
    const response = await fetch(`/blogs/${id}`, {
        method: 'DELETE',
    });

    if (response.ok) {
        loadBlogs();
    } else {
        console.error('Failed to delete blog post');
    }
}

function editBlog(id, title, body, author) {
    document.getElementById('title').value = title;
    document.getElementById('body').value = body;
    document.getElementById('author').value = author;

    blogForm.onsubmit = async (e) => {
        e.preventDefault();

        const response = await fetch(`/blogs/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ title, body, author }),
        });

        if (response.ok) {
            loadBlogs();
            blogForm.reset();
            blogForm.onsubmit = addBlog;
        } else {
            console.error('Failed to update blog post');
        }
    };
}

function addBlog(e) {
}

loadBlogs();
